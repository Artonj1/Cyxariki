package com.example.hackatonostrova65

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hackatonostrova65.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {

    //lateinit var bNavigation: BottomNavigationView
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        //ViewCompat.setElevation(bNavigation, 0f)
        //bNavigation.stateListAnimator("@null")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setTitle("Острова.65 - наш дом!")

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_holder, MainFragment.newInstance())
            .commit()

        binding.bNav.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.main_item -> {
                    supportActionBar?.setTitle("Острова.65 - наш дом!")
                    supportFragmentManager
                        .beginTransaction()
                        .replace(R.id.fragment_holder, MainFragment.newInstance())
                        .commit()

                }

                R.id.services_item -> {
                    supportActionBar?.setTitle("Сервисы")
                    supportFragmentManager
                        .beginTransaction()
                        .replace(R.id.fragment_holder, ServicesFragment.newInstance())
                        .commit()

                }

                R.id.profile_item -> {
                    Toast.makeText(this, "Тут должен быть профиль",Toast.LENGTH_SHORT).show()
                }
            }



        true
        }




    }
}