package com.example.hackatonostrova65

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.hackatonostrova65.databinding.FragmentMainBinding


class MainFragment : Fragment() {

    lateinit var binding: FragmentMainBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentMainBinding.inflate(layoutInflater)

        //supportActionBar.setDisplayHomeAsUpEnabled(true)
        //supportActionBar?.setTitle("Секции и кружки.")

        /*supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_holder, MainFragment.newInstance())
            .commit()*/


        binding.imageButton.setOnClickListener {
            startActivity(Intent(getActivity(), PDFO_Activity::class.java))
        }

        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = MainFragment()
    }
}